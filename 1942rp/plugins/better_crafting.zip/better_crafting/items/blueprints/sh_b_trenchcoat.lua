ITEM.name = "Suit with Trenchcoat Guide"
ITEM.desc = "How to make a Suit with Trenchcoat."
ITEM.price = 23.74
ITEM.noBusiness = true

ITEM.requirements = {
	{"fabric", 8},
	{"buttons", 3},
	{"dye", 4},
	{"thread", 12},
}
ITEM.result = {
    {"trenchcoatt", 1},
}