ITEM.name = "Tomato Recipe"
ITEM.desc = "How to make Tomato Plants."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"water_bucket", 1},
	{"soil", 1},
	{"tomatoseed", 1},
}
ITEM.result = {
    {"tomato", 1},
}