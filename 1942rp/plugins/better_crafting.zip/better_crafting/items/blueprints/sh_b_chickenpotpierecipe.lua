
ITEM.name = "Chicken Pot Pie Recipe"
ITEM.desc = "How to make Chicken Pot Pie."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"eggs", 2},
	{"butter", 4},
	{"sugar", 1},
	{"flour", 4},
	{"poultry", 2},
  	{"plantproduct_corn", 2},
}
ITEM.result = {
    {"chickenpotpie", 1},
}