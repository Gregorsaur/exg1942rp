
ITEM.name = "Anphetamine Recipe"
ITEM.desc = "How to make Anphetamines."
ITEM.price = 59.14
ITEM.noBusiness = true

ITEM.requirements = {
	{"methlamine", 1},
	{"aluminumshavings", 1},
}
ITEM.result = {
    {"anphetamine", 1},
}