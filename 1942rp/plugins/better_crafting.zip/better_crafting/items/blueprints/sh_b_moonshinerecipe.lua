ITEM.name = "Moonshine Guide"
ITEM.desc = "How to Moonshine."
ITEM.price = 36.71
ITEM.noBusiness = true

ITEM.requirements = {
	{"ethanol", 2},
	{"grain", 10},
	{"hops", 3},
	{"bottles", 1},
	{"water_bucket", 1},
}
ITEM.result = {
    {"moonshine", 15},
}