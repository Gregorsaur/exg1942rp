
ITEM.name = "Spaghetti and Meatballs Recipe"
ITEM.desc = "How to make Spaghetti and Meatballs."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"noodles", 6},
	{"butter", 1},
	{"flour", 2},
	{"ham", 1},
	{"poultry", 1},
  	{"plantproduct_tomato", 4},
}
ITEM.result = {
    {"spaghetti", 1},
}