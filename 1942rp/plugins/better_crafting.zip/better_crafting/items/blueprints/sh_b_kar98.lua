ITEM.name = "kar98 Blueprint"
ITEM.desc = "How to make a Kar 98k."
ITEM.price = 23.74
ITEM.noBusiness = true

ITEM.requirements = {
	{"steel", 3},
	{"screws", 2},
	{"springs", 2},
	{"wood", 2},
}
ITEM.result = {
    {"kar98k", 1},
}