ITEM.name = "Coca Plant Recipe"
ITEM.desc = "How to make Coca Plants."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"water_bucket", 2},
	{"soil", 1},
	{"cocaseed", 1},
}
ITEM.result = {
    {"leaves", 4},
}