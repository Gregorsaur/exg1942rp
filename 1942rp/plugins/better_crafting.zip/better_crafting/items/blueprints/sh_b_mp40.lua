ITEM.name = "MP40 Blueprint"
ITEM.desc = "How to make a MP-40."
ITEM.price = 23.74
ITEM.noBusiness = true

ITEM.requirements = {
	{"steel", 3},
	{"screws", 3},
	{"springs", 3},
}
ITEM.result = {
    {"mp40", 1},
}