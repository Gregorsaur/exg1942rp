ITEM.name = "Open Suit w/ Vest"
ITEM.desc = "How to make a Open Suit w/ Vest."
ITEM.price = 23.74
ITEM.noBusiness = true

ITEM.requirements = {
	{"fabric", 6},
	{"buttons", 2},
	{"dye", 3},
	{"thread", 9},
}
ITEM.result = {
    {"open_waistcoat", 1},
}