ITEM.name = "MG34 Blueprint"
ITEM.desc = "How to make a MG34."
ITEM.price = 23.74
ITEM.noBusiness = true

ITEM.requirements = {
	{"steel", 4},
	{"screws", 3},
	{"springs", 4},
	{"wood", 2},
}
ITEM.result = {
    {"mg34", 1},
}