ITEM.name = "Poppy Plant Recipe"
ITEM.desc = "How to make Poppy Plants."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"water_bucket", 2},
	{"soil", 1},
	{"poppyseed", 1},
}
ITEM.result = {
    {"poppy", 4},
}