ITEM.name = "Potato Plant Recipe"
ITEM.desc = "How to make Poppy Plants."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"water_bucket", 2},
	{"soil", 1},
	{"potatoseed", 1},
}
ITEM.result = {
    {"potato", 4},
}