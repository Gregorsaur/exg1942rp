
ITEM.name = "Oyster Rockefeller Recipe"
ITEM.desc = "How to make Oyster Rockefeller."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"oyster", 10},
	{"butter", 5},
}
ITEM.result = {
    {"oysterrockefeller", 1},
}