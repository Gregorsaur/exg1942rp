ITEM.name = "Closed Suit w/ Tie Guide"
ITEM.desc = "How to make a Closed Suit w/ Tie."
ITEM.price = 18.91
ITEM.noBusiness = true

ITEM.requirements = {
	{"fabric", 2},
	{"buttons", 2},
	{"dye", 1},
	{"thread", 3},
}
ITEM.result = {
    {"closed_tie", 1},
}