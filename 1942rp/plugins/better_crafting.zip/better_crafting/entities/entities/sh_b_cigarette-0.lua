
ITEM.name = "Cigarette Guide"
ITEM.desc = "How to make Cigarettes."
ITEM.price = 59.14
ITEM.noBusiness = true

ITEM.requirements = {
	{"tobacco", 4},
	{"rollingpaper", 4},
}
ITEM.result = {
    {"cigarette", 4},
}