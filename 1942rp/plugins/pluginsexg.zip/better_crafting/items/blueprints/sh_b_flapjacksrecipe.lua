
ITEM.name = "Flapjack Recipe"
ITEM.desc = "How to make Flapjacks."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"flour", 4},
	{"butter", 4},
	{"sugar", 2},
}
ITEM.result = {
    {"flapjacks", 1},
}