ITEM.name = "Open Suit"
ITEM.desc = "How to make an Modular Suit."
ITEM.price = 23.74
ITEM.noBusiness = true

ITEM.requirements = {
	{"fabric", 4},
	{"buttons", 4},
	{"dye", 3},
	{"thread", 8},
}
ITEM.result = {
    {"open_tie", 1},
}