
ITEM.name = "Steak Dinner Recipe"
ITEM.desc = "How to make a Steak Dinner."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"beef", 4},
	{"butter", 8},
}
ITEM.result = {
    {"steakdinner", 1},
}