
ITEM.name = "Salmon Recipe"
ITEM.desc = "How to make Salmon."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"fish", 7},
	{"butter", 5},
  	{"plantproduct_tomato", 2},
}
ITEM.result = {
    {"salmon", 1},
}