
ITEM.name = "Lobster Dinner Recipe"
ITEM.desc = "How to make Lobster Dinner."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"lobster", 10},
	{"butter", 20},
}
ITEM.result = {
    {"lobsterdinner", 1},
}