
ITEM.name = "Deviled Eggs Recipe"
ITEM.desc = "How to make Deviled Eggs."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"eggs", 4},
	{"butter", 6},
	{"sugar", 1},
}
ITEM.result = {
    {"deviledeggs", 1},
}