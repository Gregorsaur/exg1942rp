ITEM.name = "Heroin Recipe"
ITEM.desc = "How to make Heroin."
ITEM.price = 11.78
ITEM.noBusiness = true

ITEM.requirements = {
	{"morphine", 6},
}
ITEM.result = {
    {"heroinchemical", 2},
}