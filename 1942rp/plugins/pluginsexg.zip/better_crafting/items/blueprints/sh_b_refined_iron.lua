ITEM.name = "Steel Bar Blueprint"
ITEM.desc = "How to make a Steel Bar."
ITEM.price = 23.74
ITEM.noBusiness = true

ITEM.requirements = {
	{"iron_ore", 4},
	{"coal", 2},
}
ITEM.result = {
    {"steel", 1},
}