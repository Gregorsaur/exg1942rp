ITEM.name = "Opium Guide"
ITEM.desc = "How to Opium."
ITEM.price = 59.14
ITEM.noBusiness = true

ITEM.requirements = {
	{"drypoppy", 4},
}
ITEM.result = {
    {"opium", 16},
}