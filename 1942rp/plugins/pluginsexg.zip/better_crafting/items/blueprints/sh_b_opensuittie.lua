ITEM.name = "Open Suit Guide"
ITEM.desc = "How to make a Open Suit."
ITEM.price = 9.93
ITEM.noBusiness = true

ITEM.requirements = {
	{"fabric", 4},
	{"buttons", 2},
	{"dye", 1},
	{"thread", 3},
}
ITEM.result = {
    {"open", 1},
}