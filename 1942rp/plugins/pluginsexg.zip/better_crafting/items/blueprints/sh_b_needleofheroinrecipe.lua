
ITEM.name = "Heroin Needle Recipe"
ITEM.desc = "How to a Heroin Needle."
ITEM.price = 10.10
ITEM.noBusiness = true

ITEM.requirements = {
	{"heroinchemical", 1},
}
ITEM.result = {
    {"needleofheroin", 12},
}