
ITEM.name = "Turkey Dinner Recipe"
ITEM.desc = "How to make Turkey Dinner."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"turkey", 5},
	{"butter", 5},
	{"potato", 2},
  	{"plantproduct_corn", 2},
}
ITEM.result = {
    {"turkeydinner", 1},
}