ITEM.name = "Cocaine Recipe"
ITEM.desc = "How to make Cocaine"
ITEM.price = 92.14
ITEM.noBusiness = true

ITEM.requirements = {
    {"sulphuricacid", 6},
    {"kerosine", 4},
    {"calciumcarb", 8},
    {"mulchleaves", 6},
    
}
ITEM.result = {
    {"cocaine", 1},
}