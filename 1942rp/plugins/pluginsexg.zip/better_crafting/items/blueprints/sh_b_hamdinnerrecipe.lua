
ITEM.name = "Glazed Ham Dinner Recipe"
ITEM.desc = "How to make a Glazed Ham Dinner."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"ham", 7},
	{"butter", 10},
	{"potato", 1},
  	{"plantproduct_corn", 2},
}
ITEM.result = {
    {"hamdinner", 1},
}