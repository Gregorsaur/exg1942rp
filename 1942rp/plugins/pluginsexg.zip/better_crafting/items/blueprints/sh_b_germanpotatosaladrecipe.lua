
ITEM.name = "German Potato Salad Recipe"
ITEM.desc = "How to make German Potato Salad."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"sugar", 1},
	{"butter", 5},
	{"potato", 5},
}
ITEM.result = {
    {"germanpotatosalad", 1},
}