ITEM.name = "Mulched Coca Leaves"
ITEM.desc = "How to make Mulched Coca Leaves."
ITEM.price = 11.78
ITEM.noBusiness = true

ITEM.requirements = {
	{"leaves", 24},
}
ITEM.result = {
    {"mulchleaves", 6},
}