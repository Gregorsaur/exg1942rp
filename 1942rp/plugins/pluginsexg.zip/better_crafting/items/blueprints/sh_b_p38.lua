ITEM.name = "Walther P38 Blueprint"
ITEM.desc = "How to make a Walther P38."
ITEM.price = 23.74
ITEM.noBusiness = true

ITEM.requirements = {
	{"steel", 2},
	{"screws", 2},
	{"springs", 2},
	{"wood", 1},
}
ITEM.result = {
    {"p38", 1},
}