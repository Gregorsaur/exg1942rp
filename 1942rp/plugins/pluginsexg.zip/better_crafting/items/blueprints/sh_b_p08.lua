ITEM.name = "P08 Luger Blueprint"
ITEM.desc = "How to make a P08 Luger."
ITEM.price = 23.74
ITEM.noBusiness = true

ITEM.requirements = {
	{"steel", 2},
	{"screws", 2},
	{"springs", 2},
	{"wood", 1},
}
ITEM.result = {
    {"p08", 1},
}