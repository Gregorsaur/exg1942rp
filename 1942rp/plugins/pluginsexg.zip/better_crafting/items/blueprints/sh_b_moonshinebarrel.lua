ITEM.name = "Moonshine Barrel Recipe"
ITEM.desc = "How to make a Barrel Of Moonshine."
ITEM.price = 12.37
ITEM.noBusiness = true

ITEM.requirements = {
	{"moonshine", 30},
}
ITEM.result = {
    {"moonshinebarrel", 1},
}