ITEM.name = "Gold Bar Blueprint"
ITEM.desc = "How to make a Gold Bar."
ITEM.price = 30
ITEM.noBusiness = true

ITEM.requirements = {
	{"gold_ore", 5},
	{"coal", 4},
}
ITEM.result = {
    {"goldbar", 1},
}