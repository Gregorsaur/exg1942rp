
ITEM.name = "Shrimp Cocktail Recipe"
ITEM.desc = "How to make a Shrimp Cocktail."
ITEM.price = 5
ITEM.noBusiness = true

ITEM.requirements = {
	{"butter", 5},
	{"shrimp", 9},
	{"eggs", 1},
}
ITEM.result = {
    {"shrimpcocktail", 1},
}