ITEM.name = "Crafting base"
ITEM.desc = "A crafting item."
ITEM.model = "models/error.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Administration"
ITEM.noBusiness = true
ITEM.permit = "admin"