
ITEM.name = "Cigarette Carton Recipe"
ITEM.desc = "How to make Cigarette Carton."
ITEM.price = 59.14
ITEM.noBusiness = true

ITEM.requirements = {
	{"cigarette", 40},
}
ITEM.result = {
    {"cigcarton", 1},
}