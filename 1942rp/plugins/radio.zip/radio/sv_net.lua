-- server to client
util.AddNetworkString("nutRadioFreq")
-- client to server
util.AddNetworkString("nutRadioVCToggle")