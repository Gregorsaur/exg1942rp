ENT.Type = "anim";
ENT.Base = "base_anim";

ENT.PrintName= "Handle";
ENT.Author= "William";
ENT.Contact= "";
ENT.Category = "William's Car Dealer";
ENT.Purpose= "";
ENT.Instructions= "";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;