ENT.Type = "anim";
ENT.Base = "base_anim";

ENT.PrintName= "Fuel Pump";
ENT.Author= "William";
ENT.Contact= "";
ENT.Category = "William's Car Dealer";
ENT.Purpose= "";
ENT.Instructions= "";
ENT.Spawnable = true;
ENT.AdminSpawnable = true;