ENT.Type = "anim"
ENT.Base = "base_anim"

ENT.PrintName= "Fuel tank"
ENT.Author= "William"
ENT.Category = "William's Car Dealer"
ENT.Contact= ""
ENT.Purpose= "Fuel"
ENT.Instructions= ""
ENT.Spawnable = true
ENT.AdminSpawnable = true